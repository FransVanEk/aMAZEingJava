package nl.novi.amazeing.graphics;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Tile implements Drawable {
    private Color borderColor;
    private Color tileColor;
    private int baseLength;

    public Tile() {
        borderColor = Color.RED;
        tileColor = Color.GRAY;
        baseLength = 96;
    }

    public Tile(Color borderColor, Color tileColor, int baseLength) {
        this.borderColor = borderColor;
        this.tileColor = tileColor;
        this.baseLength = baseLength;
    }

    public int getBaseLength() {
        return baseLength;
    }

    public void draw(GraphicsContext gc, GraphicsPosition position) {
        double elementFactor = position.getElementFactor();
        double baseLength = this.baseLength * elementFactor;

        // Calculate the corner points of the tile
        double[][] points = getTileLayoutPoints(baseLength);

        // Adjust points based on position and angle
        calculatePolygonPointPositions(position, points);

        // Draw the tile
        gc.setFill(tileColor);
        gc.fillPolygon(new double[]{points[0][0], points[1][0], points[2][0], points[3][0]},
                new double[]{points[0][1], points[1][1], points[2][1], points[3][1]}, 4);

        gc.setStroke(borderColor);
        gc.strokePolygon(new double[]{points[0][0], points[1][0], points[2][0], points[3][0]},
                new double[]{points[0][1], points[1][1], points[2][1], points[3][1]}, 4);
    }

    private double[][] getTileLayoutPoints(double baseLength) {
        return new double[][]{
                {-baseLength / 2, -baseLength / 2}, // Top left point
                {baseLength / 2, -baseLength / 2}, // Top right point
                {baseLength / 2, baseLength / 2},  // Bottom right point
                {-baseLength / 2, baseLength / 2}   // Bottom left point
        };
    }

    private void calculatePolygonPointPositions(GraphicsPosition position, double[][] points) {
        double angle = Math.toRadians(position.getAngle());

        for (int i = 0; i < points.length; i++) {
            double rotatedX = points[i][0] * Math.cos(angle) - points[i][1] * Math.sin(angle);
            double rotatedY = points[i][0] * Math.sin(angle) + points[i][1] * Math.cos(angle);
            points[i][0] = rotatedX + position.getX();
            points[i][1] = rotatedY + position.getY();
        }
    }
}
