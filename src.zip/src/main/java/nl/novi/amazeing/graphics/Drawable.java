package nl.novi.amazeing.graphics;

import javafx.scene.canvas.GraphicsContext;

import java.awt.*;

public interface Drawable {
   // void draw(Graphics2D g2d, GraphicsPosition graphicsPosition);

    void draw(GraphicsContext gc, GraphicsPosition position);
}
