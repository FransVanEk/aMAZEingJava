package nl.novi.amazeing.graphics;


import javafx.animation.AnimationTimer;
        import javafx.application.Application;
        import javafx.scene.Group;
        import javafx.scene.Scene;
        import javafx.scene.canvas.Canvas;
        import javafx.scene.canvas.GraphicsContext;
        import javafx.stage.Stage;
        import nl.novi.amazeing.helpers.DrawHelper;
        import nl.novi.amazeing.models.Maze;
        import nl.novi.amazeing.models.position.MazePosition;
import nl.novi.amazeing.models.position.Orientation;

public class GraphicsFXRunner extends Application {
    private int NUM_STEPS = 10;
    private double blockSize = 100;
    private int frameWidth;
    private int frameHeight;
    private GraphicsContext graphicsContext;

    @Override
    public void start(Stage primaryStage) {
        Group root = new Group();
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);

        Canvas canvas = new Canvas(800, 600);
        graphicsContext = canvas.getGraphicsContext2D();
        root.getChildren().add(canvas);

        primaryStage.show();

  }

    public void performMove(Maze maze, Triangle graphicsPlayer, MazePosition currentPosition, MazePosition newPosition) {
        blockSize = calculateBlockSize(maze);
        // Calculate step sizes for each axis
        double stepX = (newPosition.getPositionX() - currentPosition.getPositionX()) / (double) NUM_STEPS;
        double stepY = (newPosition.getPositionY() - currentPosition.getPositionY()) / (double) NUM_STEPS;
        double stepAngle = DrawHelper.getRotationStepAngle(currentPosition.getOrientationDegrees(), newPosition.getOrientationDegrees(), NUM_STEPS);
        // Interpolate positions and draw at each step
        new AnimationTimer() {
            int stepCount = 0;

            @Override
            public void handle(long now) {
                double interpolatedX = currentPosition.getPositionX() + (stepCount + 1) * stepX + 0.5;
                double interpolatedY = currentPosition.getPositionY() + (stepCount + 1) * stepY + 0.5;
                double interpolatedAngle = currentPosition.getOrientationDegrees() + (stepCount * stepAngle);

                // Draw the maze
                drawMaze(graphicsContext, maze);

                // Draw the graphics at the interpolated position
                drawGraphicsAtPosition(graphicsContext, graphicsPlayer, (int)(interpolatedX * blockSize), (int)(interpolatedY * blockSize), (int)interpolatedAngle);

                stepCount++;

                // Check if animation is complete
                if (stepCount >= NUM_STEPS) {
                    stop();
                    // Draw the final position
                    drawGraphicsAtPosition(graphicsContext, graphicsPlayer, (int)((newPosition.getPositionX() + 0.5) * blockSize), (int)((newPosition.getPositionY() + 0.5) * blockSize), (int)newPosition.getOrientationDegrees());
                }
            }
        }.start();
    }

    private void drawMaze(GraphicsContext gc, Maze maze) {
        for (int x = 0; x < maze.getSizeX(); x++) {
            for (int y = 0; y < maze.getSizeY(); y++) {
                drawTileAt(gc, x, y);
            }
        }
    }

    private void drawTileAt(GraphicsContext gc, int x, int y) {
        var tile = new Tile();
        var factor = blockSize / (double)tile.getBaseLength();
        tile.draw(gc, new GraphicsPosition((int)((x + 0.5) * blockSize),(int)((y + 0.5) * blockSize), 0, factor));
    }

    private double calculateBlockSize(Maze maze) {
        return Math.min(frameWidth / (double)maze.getSizeX(), frameHeight / (double)maze.getSizeY());
    }

    // Draw graphics at a specified position
    private void drawGraphicsAtPosition(GraphicsContext gc, Triangle graphicsPlayer, int x, int y, int angle) {
        graphicsPlayer.draw(gc, new GraphicsPosition(x, y, angle, 1.0));
    }

}

