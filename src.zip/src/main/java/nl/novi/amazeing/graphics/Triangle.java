package nl.novi.amazeing.graphics;
//
//import nl.novi.amazeing.helpers.DrawHelper;
//
//import java.awt.*;
//
//public class Triangle implements Drawable {
//    private int baseLength = 40;
//    private int height = 60;
//
//    public void draw(Graphics2D g2d, GraphicsPosition position) {
//
//        var height =(int) (this.height * position.getElementFactor());
//        var baseLength = (int) (this.baseLength * position.getElementFactor());
//
//        int[][] points = {
//                {0, -height / 2}, // Top point
//                {-baseLength / 2, height / 2}, // Bottom left
//                {baseLength / 2, height / 2} // Bottom right
//        };
//
//        for (int i = 0; i < points.length; i++) {
//            var rotatedPoint = DrawHelper.rotatePointFromOrigin(points[i][0], points[i][1], position.getAngle());
//            points[i][0] = rotatedPoint.getX() + position.getX();
//            points[i][1] = rotatedPoint.getY() + position.getY();
//        }
//        g2d.setColor(Color.BLUE);
//
//        // Draw the triangle
//        g2d.fillPolygon(new int[]{points[0][0], points[1][0], points[2][0]},
//                new int[]{points[0][1], points[1][1], points[2][1]}, 3);
//    }
//}
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Triangle implements Drawable {
    private int baseLength = 40;
    private int height = 60;

    public void draw(GraphicsContext gc, GraphicsPosition position) {
        double elementFactor = position.getElementFactor();
        double baseLength = this.baseLength * elementFactor;
        double height = this.height * elementFactor;

        double[][] points = {
                {position.getX(), position.getY() - height / 2},                   // Top point
                {position.getX() - baseLength / 2, position.getY() + height / 2},  // Bottom left
                {position.getX() + baseLength / 2, position.getY() + height / 2}   // Bottom right
        };

        // Adjust points based on angle
        double angle = Math.toRadians(position.getAngle());
        for (int i = 0; i < points.length; i++) {
            double rotatedX = points[i][0] * Math.cos(angle) - points[i][1] * Math.sin(angle);
            double rotatedY = points[i][0] * Math.sin(angle) + points[i][1] * Math.cos(angle);
            points[i][0] = rotatedX;
            points[i][1] = rotatedY;
        }

        gc.setFill(Color.BLUE);
        gc.fillPolygon(new double[]{points[0][0], points[1][0], points[2][0]},
                new double[]{points[0][1], points[1][1], points[2][1]}, 3);
    }
}
