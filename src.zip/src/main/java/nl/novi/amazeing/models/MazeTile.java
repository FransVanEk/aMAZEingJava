package nl.novi.amazeing.models;

public class MazeTile {

}
