package nl.novi.amazeing.models.position;

public class MazePosition {
    public int getPositionX() {
        return positionX;
    }

    public int getPositionY() {
        return positionY;
    }

    public Orientation getOrientation() {
        return orientation;
    }

    int positionX;
    int positionY;
    Orientation orientation;

    public MazePosition(int positionX, int positionY, Orientation orientation) {
        this.positionX = positionX;
        this.positionY = positionY;
        this.orientation = orientation;
    }


    public MazePosition MakeStepInCurrentOrientation(int stepsize) {
        switch (orientation) {
            case FacingUp -> positionY -= stepsize;
            case FacingDown -> positionY += stepsize;
            case FacingLeft -> positionX -= stepsize;
            case FacingRight -> positionX += stepsize;
        }
        return this;
    }

    public MazePosition clone() {
        return new MazePosition(positionX, positionY, orientation);
    }

    public MazePosition turnLeft() {
       orientation = orientation.turnLeft();
        return this;
    }

    public MazePosition turnRight() {
        orientation= orientation.turnRight();
        return this;
    }

    public int getOrientationDegrees() {
        switch (orientation){
            case FacingRight -> {return 90;}
            case FacingDown -> {return 180;}
            case FacingLeft -> {return 270;}
            case FacingUp -> {return 0;}
        }
        return 90;
    }
}
