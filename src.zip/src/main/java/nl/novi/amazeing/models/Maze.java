package nl.novi.amazeing.models;

import java.util.ArrayList;

public class Maze {
    int sizeX;
    int sizeY;
    MazeTile[][] tiles;

    public Maze(int sizeX, int sizeY) {
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        tiles = new MazeTile[sizeX - 1][sizeY - 1];
    }

    public int getSizeX() {
        return sizeX;
    }

    public int getSizeY() {
        return sizeY;
    }
}
