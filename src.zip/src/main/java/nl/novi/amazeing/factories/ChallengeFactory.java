package nl.novi.amazeing.factories;

import nl.novi.amazeing.graphics.GraphicsFXRunner;
import nl.novi.amazeing.graphics.Triangle;
import nl.novi.amazeing.models.Maze;
import nl.novi.amazeing.models.Player;
import nl.novi.amazeing.models.position.Orientation;

public class ChallengeFactory {
    public static Challenge constructChallenge1(int sizeX, int sizeY) {
        var graphicsRunnner = new GraphicsFXRunner();
        var maze = new Maze(5,5);
        var player = new Player(new Triangle(), maze, graphicsRunnner);
        player.setPosition(0,0, Orientation.FacingRight);
        return new Challenge(maze, player);
    }
}
